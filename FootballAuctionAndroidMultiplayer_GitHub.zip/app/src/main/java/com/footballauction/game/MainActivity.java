package com.footballauction.game;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {
 @SuppressLint("SetJavaScriptEnabled")
 @Override protected void onCreate(Bundle b){
  super.onCreate(b); WebView w=new WebView(this); w.setWebViewClient(new WebViewClient());
  w.setWebChromeClient(new WebChromeClient()); w.getSettings().setJavaScriptEnabled(true);
  w.getSettings().setDomStorageEnabled(true); w.getSettings().setAllowFileAccess(true);
  w.getSettings().setMediaPlaybackRequiresUserGesture(false);
  w.loadUrl("file:///android_asset/index.html"); setContentView(w);
 }
}