# Football Auction 4.0

Private football auction game for Android/WebView.

## Player pool
The game contains 630 players spanning current stars, strong/medium players, retired players, Arab/African/Asian/South American/European players, and historical legends.

## Embedded images
During the GitHub Actions build, `download_player_images.py` resolves each player through Wikipedia and downloads a thumbnail into `app/src/main/assets/players/`. The build stops if any required player image is missing, preventing a broken-image APK from being produced.

## Auction rules
- Custom price is an absolute final price in millions: current 28M -> entering 30 means 30M.
- Custom price must be at least current price + 1M.
- `خده` awards the player to the current highest bidder; it cannot be used by the current highest bidder to take the same player.
- The losing side receives a free player of the same position, when an open slot and unused player exist.
- AI follows the same auction and free-player rules.

## DELUXE scoring and images
- Final result is decided by the in-game automatic judge: sum all player ratings + selected coach rating.
- Coach is selected according to each player's remaining budget; remaining money breaks ties.
- Coach portraits are downloaded into `app/src/main/assets/coaches` at build time.
- Player portraits are downloaded into `app/src/main/assets/players` at build time.
- The build stops if required images cannot be embedded, preventing a broken-image APK.
- Original/licensed or publicly reusable portraits are preferred. Do not copy FIFA/EA card screenshots or proprietary card art into the app.

IMAGE GUARANTEE:
The database currently contains 630 player entries. The build is intentionally strict: it will NOT produce an APK if any required player or coach image is missing. The GitHub build log must report Embedded images: 630/630 and Embedded coach images: 9/9 before the APK is considered complete.

IMPORTANT: the source ZIP does not contain the downloaded portraits yet. They are downloaded by the GitHub build into app/src/main/assets/players and app/src/main/assets/coaches, then packaged into the APK. Do not call the APK complete until the log shows 630/630 and 9/9.
