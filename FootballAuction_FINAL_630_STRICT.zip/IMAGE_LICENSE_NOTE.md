# Image source note

Player/coach portrait downloading is performed at build time. Each image source must be checked for its applicable reuse/license terms before distribution. Wikimedia Commons hosts freely licensed/public-domain media, but individual files can have different attribution and license requirements. The app should retain required attribution information for any reused image.

Do not include proprietary FIFA/EA card screenshots or card art without permission.
