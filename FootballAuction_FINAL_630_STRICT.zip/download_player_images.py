#!/usr/bin/env python3
import json, re, sys, time
from pathlib import Path
from urllib.parse import quote
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
HTML = ROOT / 'app/src/main/assets/index.html'
OUT = ROOT / 'app/src/main/assets/players'
COACH_OUT = ROOT / 'app/src/main/assets/coaches'
OUT.mkdir(parents=True, exist_ok=True)
COACH_OUT.mkdir(parents=True, exist_ok=True)

text = HTML.read_text(encoding='utf-8')
block = text.split('const DB=[', 1)[1].split('];', 1)[0]
names = []
for m in re.finditer(r'\["(?:[^"\\]|\\.)*","(?:[^"\\]|\\.)*","(?:[^"\\]|\\.)*",\d+,"(?:[^"\\]|\\.)*","([^"]+)"\]', block):
    n = m.group(1)
    if n not in names:
        names.append(n)

def slug(n):
    return re.sub(r'^_|_$', '', re.sub(r'[^a-z0-9]+', '_', n.lower()))

def get_json(url):
    req = Request(url, headers={'User-Agent':'FootballAuctionPrivateGame/1.0'})
    with urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode('utf-8'))

def get_bytes(url):
    req = Request(url, headers={'User-Agent':'FootballAuctionPrivateGame/1.0'})
    with urlopen(req, timeout=30) as r:
        return r.read()

def thumbnail_for(name):
    # First try the exact Wikipedia page title.
    base='https://en.wikipedia.org/w/api.php?action=query&prop=pageimages&format=json&piprop=thumbnail&pithumbsize=480&titles='
    try:
        data=get_json(base+quote(name))
        pages=data.get('query',{}).get('pages',{})
        page=next(iter(pages.values()),{})
        thumb=(page.get('thumbnail') or {}).get('source')
        if thumb: return thumb
    except Exception:
        pass
    # Then search Wikipedia for the closest page with a thumbnail.
    search='https://en.wikipedia.org/w/api.php?action=query&list=search&format=json&srlimit=5&srsearch='
    try:
        data=get_json(search+quote(name+' footballer'))
        for item in data.get('query',{}).get('search',[]):
            title=item.get('title','')
            d=get_json(base+quote(title))
            pages=d.get('query',{}).get('pages',{})
            page=next(iter(pages.values()),{})
            thumb=(page.get('thumbnail') or {}).get('source')
            if thumb: return thumb
    except Exception:
        pass
    return None

ok=0
missing=[]
for i,name in enumerate(names,1):
    path=OUT/(slug(name)+'.jpg')
    if path.exists() and path.stat().st_size > 5000:
        ok += 1
        continue
    try:
        url=thumbnail_for(name)
        if not url:
            missing.append(name); print(f'[{i}/{len(names)}] NO IMAGE: {name}')
        else:
            data=get_bytes(url)
            if len(data) > 1000:
                path.write_bytes(data); ok += 1
                print(f'[{i}/{len(names)}] OK: {name}')
            else:
                missing.append(name)
    except Exception as e:
        missing.append(name); print(f'[{i}/{len(names)}] FAILED: {name}: {e}')
    time.sleep(0.08)

# Coaches: download licensed/available Wikipedia thumbnails into the APK too.
coach_names=["Pep Guardiola","Carlo Ancelotti","José Mourinho","Jürgen Klopp","Zinedine Zidane","Arsène Wenger","Vicente del Bosque","Hassan Shehata","Manuel José de Jesus"]
coach_missing=[]
for i,name in enumerate(coach_names,1):
    path=COACH_OUT/(slug(name)+'.jpg')
    if path.exists() and path.stat().st_size>5000:
        continue
    try:
        url=thumbnail_for(name)
        if not url: coach_missing.append(name); print(f'[COACH {i}/{len(coach_names)}] NO IMAGE: {name}'); continue
        data=get_bytes(url)
        if len(data)>1000: path.write_bytes(data); print(f'[COACH {i}/{len(coach_names)}] OK: {name}')
        else: coach_missing.append(name)
    except Exception as e:
        coach_missing.append(name); print(f'[COACH {i}/{len(coach_names)}] FAILED: {name}: {e}')
    time.sleep(0.08)

print(f'Embedded coach images: {len(coach_names)-len(coach_missing)}/{len(coach_names)}')
if coach_missing:
    print('Missing coach images:')
    for n in coach_missing: print(' -',n)

print(f'Embedded images: {ok}/{len(names)}')
if missing:
    print('Missing images:')
    for n in missing: print(' -',n)
# Do not ship a broken-image APK: fail the build if too many images are missing.
if coach_missing or missing:
    raise SystemExit(f'IMAGE CHECK FAILED: {len(missing)} player images and {len(coach_missing)} coach images are missing. APK build is stopped until every required image is embedded.')
