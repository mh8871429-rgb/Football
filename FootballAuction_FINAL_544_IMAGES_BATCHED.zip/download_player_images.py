#!/usr/bin/env python3
import json, re, sys, time
from pathlib import Path
from urllib.parse import quote
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
HTML = ROOT / 'app/src/main/assets/index.html'
OUT = ROOT / 'app/src/main/assets/players'
COACH_OUT = ROOT / 'app/src/main/assets/coaches'
OUT.mkdir(parents=True, exist_ok=True)
COACH_OUT.mkdir(parents=True, exist_ok=True)

text = HTML.read_text(encoding='utf-8')
block = text.split('const DB=[', 1)[1].split('];', 1)[0]
names = []
for m in re.finditer(r'\["(?:[^"\\]|\\.)*","(?:[^"\\]|\\.)*","(?:[^"\\]|\\.)*",\d+,"(?:[^"\\]|\\.)*","([^"]+)"\]', block):
    n = m.group(1)
    if n not in names:
        names.append(n)

def slug(n):
    return re.sub(r'^_|_$', '', re.sub(r'[^a-z0-9]+', '_', n.lower()))

def get_json(url, attempts=6):
    last=None
    for a in range(attempts):
        try:
            req = Request(url, headers={
                'User-Agent':'FootballAuctionPrivateGame/1.0 (private game image fetcher; contact: github-actions)',
                'Accept':'application/json'
            })
            with urlopen(req, timeout=45) as r:
                return json.loads(r.read().decode('utf-8'))
        except Exception as e:
            last=e
            time.sleep(min(8, 1.2*(a+1)))
    raise last

def get_bytes(url, attempts=6):
    last=None
    for a in range(attempts):
        try:
            req = Request(url, headers={
                'User-Agent':'FootballAuctionPrivateGame/1.0 (private game image fetcher; contact: github-actions)',
                'Accept':'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8'
            })
            with urlopen(req, timeout=45) as r:
                return r.read()
        except Exception as e:
            last=e
            time.sleep(min(8, 1.2*(a+1)))
    raise last

API='https://en.wikipedia.org/w/api.php'

def batch_thumbnails(titles):
    """Fetch exact-title thumbnails in batches of up to 50, avoiding one API call per player."""
    out={}
    for off in range(0, len(titles), 50):
        batch=titles[off:off+50]
        params='?action=query&prop=pageimages&format=json&piprop=thumbnail&pithumbsize=480&redirects=1&titles='+quote('|'.join(batch))
        try:
            data=get_json(API+params)
            for page in data.get('query',{}).get('pages',{}).values():
                title=page.get('title')
                thumb=(page.get('thumbnail') or {}).get('source')
                if title and thumb:
                    out[title]=thumb
        except Exception as e:
            print(f'WARNING: batch thumbnail request failed ({off+1}-{off+len(batch)}): {e}')
        time.sleep(0.5)
    return out

def search_thumbnail(name):
    """Fallback search for names whose exact Wikipedia title has no thumbnail."""
    try:
        search='?action=query&generator=search&format=json&gsrsearch='+quote(name+' footballer')+'&gsrlimit=5&prop=pageimages&piprop=thumbnail&pithumbsize=480'
        data=get_json(API+search)
        pages=data.get('query',{}).get('pages',{})
        # Prefer a title containing the person's surname/name tokens.
        candidates=[]
        needle=[x for x in re.split(r'\s+', name.lower()) if x]
        for page in pages.values():
            title=page.get('title','')
            thumb=(page.get('thumbnail') or {}).get('source')
            score=sum(1 for x in needle if x in title.lower())
            if thumb: candidates.append((score,thumb,title))
        if candidates:
            candidates.sort(reverse=True)
            return candidates[0][1]
    except Exception:
        pass
    return None


print(f'Player records detected: {len(names)}')
ok=0
missing=[]
thumbs=batch_thumbnails(names)
for i,name in enumerate(names,1):
    path=OUT/(slug(name)+'.jpg')
    if path.exists() and path.stat().st_size > 5000:
        ok += 1
        print(f'[{i}/{len(names)}] CACHED: {name}')
        continue
    url=thumbs.get(name) or search_thumbnail(name)
    if not url:
        missing.append(name); print(f'[{i}/{len(names)}] NO IMAGE: {name}'); continue
    try:
        data=get_bytes(url)
        if len(data) > 1000:
            path.write_bytes(data); ok += 1
            print(f'[{i}/{len(names)}] OK: {name}')
        else:
            missing.append(name); print(f'[{i}/{len(names)}] BAD IMAGE: {name}')
    except Exception as e:
        missing.append(name); print(f'[{i}/{len(names)}] FAILED: {name}: {e}')
    time.sleep(0.12)

# Coaches: fetch the same way and embed them locally.
coach_names=["Pep Guardiola","Carlo Ancelotti","José Mourinho","Jürgen Klopp","Zinedine Zidane","Arsène Wenger","Vicente del Bosque","Hassan Shehata","Manuel José de Jesus"]
coach_missing=[]
coach_thumbs=batch_thumbnails(coach_names)
for i,name in enumerate(coach_names,1):
    path=COACH_OUT/(slug(name)+'.jpg')
    if path.exists() and path.stat().st_size>5000:
        print(f'[COACH {i}/{len(coach_names)}] CACHED: {name}'); continue
    url=coach_thumbs.get(name) or search_thumbnail(name)
    if not url:
        coach_missing.append(name); print(f'[COACH {i}/{len(coach_names)}] NO IMAGE: {name}'); continue
    try:
        data=get_bytes(url)
        if len(data)>1000:
            path.write_bytes(data); print(f'[COACH {i}/{len(coach_names)}] OK: {name}')
        else:
            coach_missing.append(name); print(f'[COACH {i}/{len(coach_names)}] BAD IMAGE: {name}')
    except Exception as e:
        coach_missing.append(name); print(f'[COACH {i}/{len(coach_names)}] FAILED: {name}: {e}')
    time.sleep(0.15)

print(f'Embedded coach images: {len(coach_names)-len(coach_missing)}/{len(coach_names)}')
if coach_missing:
    print('Missing coach images:')
    for n in coach_missing: print(' -',n)

print(f'Embedded images: {ok}/{len(names)}')
if missing:
    print('Missing images:')
    for n in missing: print(' -',n)
# Do not ship a broken-image APK: fail the build if too many images are missing.
if coach_missing or missing:
    raise SystemExit(f'IMAGE CHECK FAILED: {len(missing)} player images and {len(coach_missing)} coach images are missing. APK build is stopped until every required image is embedded.')
